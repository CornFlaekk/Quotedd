#!/bin/bash
redis-server & redis-cli