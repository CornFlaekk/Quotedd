#!/bin/bash
flask run --debug