#!/bin/bash
redis-server &
flask run --debug